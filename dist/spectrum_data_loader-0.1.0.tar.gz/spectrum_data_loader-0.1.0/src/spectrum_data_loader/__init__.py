# src/spectrum_data_loader/__init__.py

# Importa las funciones públicas desde el módulo 'parser'
# para que estén disponibles directamente en el nivel superior de la librería.
from .parser import load_xy_data, load_df_data