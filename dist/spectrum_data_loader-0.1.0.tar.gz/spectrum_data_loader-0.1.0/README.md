# Spectrum Data Loader

Una librería simple y robusta para cargar datos de espectros de 2 columnas (X, Y) desde archivos de texto.

## Instalación

```bash
pip install spectrum-data-loader